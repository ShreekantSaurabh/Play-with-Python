class FirstClass:
    pass


    '''obj  = FistClass()'''
